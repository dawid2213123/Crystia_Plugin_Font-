Prefixy rang - resource pack wygenerowany w ServerCreators.pl

Każda ranga to znak z prywatnego zakresu Unicode:
gracz  ->  \uE000  (gracz_1.png, 38x13px)
HEADADMIN  ->  \uE001  (headadmin_2.png, 60x13px)
admin  ->  \uE002  (admin_3.png, 36x13px)
helper  ->  \uE003  (helper_4.png, 44x13px)
\ROOT  ->  \uE004  (root_5.png, 32x13px)
\MODERATOR  ->  \uE005  (moderator_6.png, 62x13px)
VIP  ->  \uE006  (vip_7.png, 24x13px)
SVIP  ->  \uE007  (svip_8.png, 30x13px)
CRYSTIA  ->  \uE008  (crystia_9.png, 48x13px)

Użycie w tekście JSON (np. czat, tablista, nazwa): {"text":"\uE000 Nick"}